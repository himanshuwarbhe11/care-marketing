# CareMarketing.space website update

## Files
- `index.html` — website structure and content
- `style.css` — responsive styling
- `script.js` — mobile navigation, year, and WhatsApp enquiry form

## Deploy
Replace the existing `index.html`, `style.css`, and `script.js` in the `himanshuwarbhe11/care-marketing` repository with these files, then commit and push to the branch used by GitHub Pages.

## Before publishing
1. Verify the WhatsApp number `+91 82753 20747`.
2. Verify the product enquiry number `+91 98227 10002`.
3. Replace stock photos with your own product photos when available.
4. The contact form opens WhatsApp; it does not store enquiries in a database.
